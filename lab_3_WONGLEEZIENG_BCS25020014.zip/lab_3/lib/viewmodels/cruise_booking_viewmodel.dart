import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/cruise_destination.dart';

class CruiseBookingViewModel extends ChangeNotifier {
  final CruiseDestination destination;

  late int _starCount;
  bool _isStarred = false;
  DateTime _selectedDate = DateTime(2026, 11, 15);
  late String _selectedTransportMode;
  late String _selectedPackage;
  bool _isDarkMode = false;

  CruiseBookingViewModel({CruiseDestination? destination})
      : destination = destination ?? CruiseDestination.rajangRiverDefault() {
    _starCount = this.destination.initialStarCount;
    _selectedTransportMode = this.destination.availableTransportModes.first;
    _selectedPackage = this.destination.availablePackages.first;
  }

  int get starCount => _starCount;
  bool get isStarred => _isStarred;
  DateTime get selectedDate => _selectedDate;
  String get selectedTransportMode => _selectedTransportMode;
  String get selectedPackage => _selectedPackage;
  bool get isDarkMode => _isDarkMode;

  String get formattedDate {
    final String day = _selectedDate.day.toString().padLeft(2, '0');
    final String month = _selectedDate.month.toString().padLeft(2, '0');
    final String year = _selectedDate.year.toString();
    return '$day/$month/$year';
  }

  void toggleStar() {
    HapticFeedback.lightImpact();
    _isStarred = !_isStarred;
    _starCount += _isStarred ? 1 : -1;
    notifyListeners();
  }

  void updateSelectedDate(DateTime newDate) {
    HapticFeedback.selectionClick();
    _selectedDate = newDate;
    notifyListeners();
  }

  void updateSelectedTransportMode(String? newMode) {
    if (newMode != null && newMode != _selectedTransportMode) {
      HapticFeedback.selectionClick();
      _selectedTransportMode = newMode;
      notifyListeners();
    }
  }

  void updateSelectedPackage(String? newPackage) {
    if (newPackage != null && newPackage != _selectedPackage) {
      HapticFeedback.selectionClick();
      _selectedPackage = newPackage;
      notifyListeners();
    }
  }

  void toggleDarkMode(bool value) {
    if (_isDarkMode != value) {
      HapticFeedback.lightImpact();
      _isDarkMode = value;
      notifyListeners();
    }
  }
}