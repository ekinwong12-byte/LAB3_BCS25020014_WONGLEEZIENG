class CruiseDestination {
  final String title;
  final String location;
  final String portraitDescription;
  final String landscapeDescription;
  final String imageAsset;
  final String portraitCaption;
  final String landscapeCaption;
  final int initialStarCount;
  final String contactPhone;
  final List<String> availableTransportModes;
  final List<String> availablePackages;

  const CruiseDestination({
    required this.title,
    required this.location,
    required this.portraitDescription,
    required this.landscapeDescription,
    required this.imageAsset,
    required this.portraitCaption,
    required this.landscapeCaption,
    required this.initialStarCount,
    required this.contactPhone,
    required this.availableTransportModes,
    required this.availablePackages,
  });

  factory CruiseDestination.rajangRiverDefault() {
    return const CruiseDestination(
      title: 'Rajang River Express Cruise',
      location: 'Sibu Waterfront, Sarawak',
      portraitDescription:
      "Experience the heart of Sibu along Malaysia's longest river, the Rajang. "
          'Cruise past historic temples, timber hubs, and waterfront settlements.',
      landscapeDescription:
      "Experience the heart of Sibu along Malaysia's longest river, the Rajang. "
          'Cruise past historic temples, timber hubs, and traditional waterfront '
          'settlements while experiencing authentic Sarawakian hospitality.',
      imageAsset: 'assets/images/rajang_river.jpg',
      portraitCaption: 'Sibu Esplanade Landmark',
      landscapeCaption: 'Rajang River Horizon',
      initialStarCount: 81,
      contactPhone: '+60 84-333 411',
      availableTransportModes: [
        'Express Boat',
        'Heritage Riverboat',
        'Wooden Longboat',
        'River Speedboat',
      ],
      availablePackages: [
        'Private River Cruise',
        'Sunset Cruise',
        'Sunrise Cruise',
        'Rural Cruise',
        'SMI Park Cruise',
      ],
    );
  }
}