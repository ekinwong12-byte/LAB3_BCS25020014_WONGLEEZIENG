import 'package:flutter/material.dart';

class BookingControlsWidget extends StatelessWidget {
  final String formattedDate;
  final DateTime selectedDate;
  final ValueChanged<DateTime> onDateChanged;
  final String selectedTransportMode;
  final List<String> availableTransportModes;
  final ValueChanged<String?> onTransportModeChanged;
  final String selectedPackage;
  final List<String> availablePackages;
  final ValueChanged<String?> onPackageChanged;
  final bool isDarkMode;
  final ValueChanged<bool> onDarkModeChanged;
  final VoidCallback onReservePressed;
  final bool isLandscape;

  const BookingControlsWidget({
    super.key,
    required this.formattedDate,
    required this.selectedDate,
    required this.onDateChanged,
    required this.selectedTransportMode,
    required this.availableTransportModes,
    required this.onTransportModeChanged,
    required this.selectedPackage,
    required this.availablePackages,
    required this.onPackageChanged,
    required this.isDarkMode,
    required this.onDarkModeChanged,
    required this.onReservePressed,
    this.isLandscape = false,
  });

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2025, 1, 1),
      lastDate: DateTime(2030, 12, 31),
      helpText: 'Select Rajang River Cruise Date',
    );
    if (picked != null) {
      onDateChanged(picked);
    }
  }

  Widget _buildDropdownRow({
    required BuildContext context,
    required IconData icon,
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      children: [
        Icon(icon, size: 19, color: colorScheme.primary),
        const SizedBox(width: 10),
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurfaceVariant,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.45),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: colorScheme.outlineVariant.withValues(alpha: 0.7),
              ),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                isExpanded: true,
                borderRadius: BorderRadius.circular(12),
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  size: 20,
                  color: colorScheme.primary,
                ),
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                items: items.map((String item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(
                      item,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                }).toList(),
                onChanged: onChanged,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: EdgeInsets.fromLTRB(20, isLandscape ? 10 : 4, 20, 8),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: colorScheme.surfaceContainerLowest,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: colorScheme.outlineVariant.withValues(alpha: 0.55),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isLandscape) ...[
              Row(
                children: [
                  Icon(
                    Icons.tune_rounded,
                    size: 18,
                    color: colorScheme.primary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Trip Preferences',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
            // 1. Visit Date Picker
            Row(
              children: [
                Icon(
                  Icons.calendar_month_rounded,
                  size: 19,
                  color: colorScheme.primary,
                ),
                const SizedBox(width: 10),
                Text(
                  'Cruise Date:',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => _pickDate(context),
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 13,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            formattedDate,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: colorScheme.onPrimaryContainer,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Icon(
                            Icons.edit_calendar_rounded,
                            size: 15,
                            color: colorScheme.onPrimaryContainer,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            // 2. Transport Mode Dropdown
            _buildDropdownRow(
              context: context,
              icon: Icons.sailing_rounded,
              label: isLandscape ? 'Mode:' : 'Transport Mode:',
              value: selectedTransportMode,
              items: availableTransportModes,
              onChanged: onTransportModeChanged,
            ),
            const SizedBox(height: 14),
            // 3. Cruise Package Dropdown
            _buildDropdownRow(
              context: context,
              icon: Icons.explore_rounded,
              label: isLandscape ? 'Package:' : 'Cruise Package:',
              value: selectedPackage,
              items: availablePackages,
              onChanged: onPackageChanged,
            ),
            Divider(
              height: 26,
              color: colorScheme.outlineVariant.withValues(alpha: 0.5),
            ),
            // 4. Dark Mode Theme Switch
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 220),
                      child: Icon(
                        isDarkMode
                            ? Icons.dark_mode_rounded
                            : Icons.light_mode_rounded,
                        key: ValueKey<bool>(isDarkMode),
                        size: 20,
                        color: isDarkMode ? Colors.amber : colorScheme.primary,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Dark Mode Theme',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                Switch.adaptive(
                  value: isDarkMode,
                  onChanged: onDarkModeChanged,
                ),
              ],
            ),
            const SizedBox(height: 14),
            // 5. Quick Reservation Summary Button
            SizedBox(
              width: double.infinity,
              child: FilledButton.tonalIcon(
                onPressed: onReservePressed,
                icon: const Icon(Icons.confirmation_number_outlined, size: 18),
                label: const Text(
                  'Review Cruise Booking',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}