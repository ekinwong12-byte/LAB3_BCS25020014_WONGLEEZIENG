import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ActionBarWidget extends StatelessWidget {
  final String contactPhone;
  final String destinationTitle;

  const ActionBarWidget({
    super.key,
    required this.contactPhone,
    required this.destinationTitle,
  });

  void _showFeedback(BuildContext context, IconData icon, String message) {
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 10),
              Expanded(child: Text(message)),
            ],
          ),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: colorScheme.surfaceContainerLowest,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: colorScheme.outlineVariant.withValues(alpha: 0.55),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildActionButton(
              context: context,
              icon: Icons.call_rounded,
              label: 'CALL',
              onTap: () => _showFeedback(
                context,
                Icons.call_rounded,
                'Calling Sibu Cruise Desk ($contactPhone)...',
              ),
            ),
            _buildActionButton(
              context: context,
              icon: Icons.near_me_rounded,
              label: 'ROUTE',
              onTap: () => _showFeedback(
                context,
                Icons.near_me_rounded,
                'Opening navigation to Sibu Waterfront Jetty...',
              ),
            ),
            _buildActionButton(
              context: context,
              icon: Icons.share_rounded,
              label: 'SHARE',
              onTap: () => _showFeedback(
                context,
                Icons.share_rounded,
                'Sharing "$destinationTitle" itinerary...',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final colorScheme = Theme.of(context).colorScheme;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: colorScheme.primary.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: colorScheme.primary, size: 20),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: colorScheme.primary,
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}