import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/cruise_destination.dart';
import '../viewmodels/cruise_booking_viewmodel.dart';
import 'widgets/action_bar_widget.dart';
import 'widgets/booking_controls_widget.dart';
import 'widgets/description_widget.dart';
import 'widgets/header_image_widget.dart';
import 'widgets/title_section_widget.dart';

class CruiseBookingScreen extends StatelessWidget {
  final CruiseBookingViewModel viewModel;

  const CruiseBookingScreen({
    super.key,
    required this.viewModel,
  });

  void _showBookingSummary(BuildContext context) {
    HapticFeedback.mediumImpact();
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Prevents height cap overflow in landscape
      useSafeArea: true,
      showDragHandle: true,
      constraints: const BoxConstraints(maxWidth: 540),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            24,
            0,
            24,
            isLandscape ? 18 : 28,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.directions_boat_rounded,
                      color: colorScheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Cruise Reservation Summary',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          viewModel.destination.location,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: isLandscape ? 14 : 20),
              _summaryRow(
                context,
                Icons.calendar_month_rounded,
                'Cruise Date',
                viewModel.formattedDate,
              ),
              SizedBox(height: isLandscape ? 8 : 12),
              _summaryRow(
                context,
                Icons.sailing_rounded,
                'Transport Mode',
                viewModel.selectedTransportMode,
              ),
              SizedBox(height: isLandscape ? 8 : 12),
              _summaryRow(
                context,
                Icons.explore_rounded,
                'Cruise Package',
                viewModel.selectedPackage,
              ),
              SizedBox(height: isLandscape ? 16 : 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(sheetContext);
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        SnackBar(
                          content: Text(
                            'Reserved ${viewModel.selectedPackage} (${viewModel.selectedTransportMode}) for ${viewModel.formattedDate}',
                          ),
                        ),
                      );
                  },
                  icon: const Icon(Icons.check_circle_outline_rounded),
                  label: const Text('Confirm Cruise Selection'),
                  style: FilledButton.styleFrom(
                    padding: EdgeInsets.symmetric(
                      vertical: isLandscape ? 12 : 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _summaryRow(
      BuildContext context,
      IconData icon,
      String label,
      String value,
      ) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Icon(icon, size: 18, color: theme.colorScheme.primary),
        const SizedBox(width: 10),
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.end,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: viewModel,
      builder: (context, _) {
        return OrientationBuilder(
          builder: (context, orientation) {
            final isLandscape = orientation == Orientation.landscape;
            final destination = viewModel.destination;

            return Scaffold(
              appBar: AppBar(
                title: Text(
                  isLandscape
                      ? 'Sibu River Cruise & Heritage'
                      : 'Sibu River Cruise & Heritage',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: isLandscape ? 16 : 17,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.1,
                  ),
                ),
                actions: [
                  if (isLandscape)
                    Padding(
                      padding: const EdgeInsets.only(right: 12, left: 8),
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.25),
                            ),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.screen_rotation_rounded, size: 12),
                              SizedBox(width: 4),
                              Text(
                                'Orientation.landscape',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  else
                    IconButton(
                      icon: const Icon(Icons.info_outline_rounded),
                      tooltip: 'About Sibu River Cruise',
                      onPressed: () {
                        ScaffoldMessenger.of(context)
                          ..hideCurrentSnackBar()
                          ..showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Sibu Municipal Council • Rajang River Eco-Tourism',
                              ),
                            ),
                          );
                      },
                    ),
                ],
              ),
              body: AnimatedSwitcher(
                duration: const Duration(milliseconds: 280),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: isLandscape
                    ? _buildLandscapeLayout(context, destination)
                    : _buildPortraitLayout(context, destination),
              ),
            );
          },
        );
      },
    );
  }

  /// Figure 1: Portrait Single-Column Scrollable Layout (ListView)
  Widget _buildPortraitLayout(
      BuildContext context,
      CruiseDestination destination,
      ) {
    return ListView(
      key: const ValueKey('portrait_layout'),
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        HeaderImageWidget(
          imageAsset: destination.imageAsset,
          caption: destination.portraitCaption,
          height: 235,
          isLandscape: false,
        ),
        TitleSectionWidget(
          title: destination.title,
          location: destination.location,
          starCount: viewModel.starCount,
          isStarred: viewModel.isStarred,
          onStarTap: viewModel.toggleStar,
        ),
        ActionBarWidget(
          contactPhone: destination.contactPhone,
          destinationTitle: destination.title,
        ),
        DescriptionWidget(
          description: destination.portraitDescription,
        ),
        BookingControlsWidget(
          formattedDate: viewModel.formattedDate,
          selectedDate: viewModel.selectedDate,
          onDateChanged: viewModel.updateSelectedDate,
          selectedTransportMode: viewModel.selectedTransportMode,
          availableTransportModes: destination.availableTransportModes,
          onTransportModeChanged: viewModel.updateSelectedTransportMode,
          selectedPackage: viewModel.selectedPackage,
          availablePackages: destination.availablePackages,
          onPackageChanged: viewModel.updateSelectedPackage,
          isDarkMode: viewModel.isDarkMode,
          onDarkModeChanged: viewModel.toggleDarkMode,
          onReservePressed: () => _showBookingSummary(context),
          isLandscape: false,
        ),
      ],
    );
  }

  /// Figure 2: Landscape Side-by-Side Split Pane (Row + Expanded)
  Widget _buildLandscapeLayout(
      BuildContext context,
      CruiseDestination destination,
      ) {
    return Row(
      key: const ValueKey('landscape_layout'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Left Pane: Header Image + About the Destination
        Expanded(
          flex: 10,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                HeaderImageWidget(
                  imageAsset: destination.imageAsset,
                  caption: destination.landscapeCaption,
                  height: 195,
                  isLandscape: true,
                ),
                DescriptionWidget(
                  heading: 'About the Destination',
                  description: destination.landscapeDescription,
                ),
              ],
            ),
          ),
        ),
        VerticalDivider(
          width: 1,
          thickness: 1,
          color: Theme.of(context)
              .colorScheme
              .outlineVariant
              .withValues(alpha: 0.5),
        ),
        // Right Pane: Title + Action Bar + Interactive Controls
        Expanded(
          flex: 11,
          child: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.only(bottom: 20),
            children: [
              TitleSectionWidget(
                title: destination.title,
                location: destination.location,
                starCount: viewModel.starCount,
                isStarred: viewModel.isStarred,
                onStarTap: viewModel.toggleStar,
              ),
              ActionBarWidget(
                contactPhone: destination.contactPhone,
                destinationTitle: destination.title,
              ),
              BookingControlsWidget(
                formattedDate: viewModel.formattedDate,
                selectedDate: viewModel.selectedDate,
                onDateChanged: viewModel.updateSelectedDate,
                selectedTransportMode: viewModel.selectedTransportMode,
                availableTransportModes: destination.availableTransportModes,
                onTransportModeChanged: viewModel.updateSelectedTransportMode,
                selectedPackage: viewModel.selectedPackage,
                availablePackages: destination.availablePackages,
                onPackageChanged: viewModel.updateSelectedPackage,
                isDarkMode: viewModel.isDarkMode,
                onDarkModeChanged: viewModel.toggleDarkMode,
                onReservePressed: () => _showBookingSummary(context),
                isLandscape: true,
              ),
            ],
          ),
        ),
      ],
    );
  }
}